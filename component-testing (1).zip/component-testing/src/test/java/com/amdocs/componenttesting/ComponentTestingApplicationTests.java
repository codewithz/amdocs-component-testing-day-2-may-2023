package com.amdocs.componenttesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComponentTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
