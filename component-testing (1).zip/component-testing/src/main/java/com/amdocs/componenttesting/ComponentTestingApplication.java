package com.amdocs.componenttesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComponentTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComponentTestingApplication.class, args);
	}

}
